Alethi Games 2020 - All rights reserved

Programmers:
Migaspin Casterwill
Potato Dwarf
Tiago Antunes

Beta Testers:
Awart
Lenka Lemeš